--write a bolck that outputs 'hello' and save it as test.sql
--then run this script again

begin
dbms_output.put_line('hello');
end;
