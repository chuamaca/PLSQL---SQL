laboratorio dos - tablas

1.- 
-- modificar la longitud de todos los campos varchar2(20) a varchar2(30) en la tabla products

2.- EN PRODUCTS
-- agregar las columnas
 -- name , para guardar los nombres de los vendedores.
 -- last_name, para guardar los apellidos de los vendedores.

3.- 
-- eliminar la columna PROD_WEIGHT_CLASS DE LA TABLA PRODUCTS.

4.- CONECTARSE CON USER HR

-- crear una tabla backup de la tabla HR.EMPLOYEES y luego hacerla de tipo READ O lectura.